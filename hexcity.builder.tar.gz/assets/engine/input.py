import pygame
from engine.hex_math import pixel_to_hex

class InputHandler:
    def __init__(self, camera, game_map):
        self.camera = camera
        self.game_map = game_map
        self.selected_type = "grass"
        self.money = 1000

        self.tile_costs = {
            "grass": 10,
            "water": 10,
            "forest": 25,
            "hill": 25,
            "residential": 50,
            "commercial": 100,
            "industrial": 75,
            "utility": 150,
            "park": 20

        }
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                self.selected_type = "grass"
            elif event.key == pygame.K_2:
                self.selected_type = "water"
            elif event.key == pygame.K_3:
                self.selected_type = "forest"
            elif event.key == pygame.K_4:
                self.selected_type = "hill"
            elif event.key == pygame.K_5:
                self.selected_type = "residential"
            elif event.key == pygame.K_6:
                self.selected_type = "commercial"
            elif event.key == pygame.K_7:
                self.selected_type = "industrial"
            elif event.key == pygame.K_8:
                self.selected_type = "utility"
            elif event.key == pygame.K_9:
                self.selected_type = "park"

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = pygame.mouse.get_pos()
            mx += self.camera.x
            my += self.camera.y
            q, r = pixel_to_hex(mx, my)

            if self.game_map.get_tile(q, r) is None:
                if self.game_map.is_adjacent_to_existing(q, r):
                    cost = self.tile_costs.get[self.selected_type]
                    if self.money >= cost:
                       self.money -= cost
                       self.game_map.add_tile(q, r, self.selected_type)